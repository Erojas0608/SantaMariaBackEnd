﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Transaccion
    {
        public Transaccion()
        {
            IdRols = new HashSet<Rol>();
        }

        public int IdTransaccion { get; set; }
        public string Descripcion { get; set; } = null!;
        public string DescripcionCorta { get; set; } = null!;
        public string? Observacion { get; set; }
        public string RutaUrl { get; set; } = null!;
        public string? Icono { get; set; }
        public int IdModulo { get; set; }
        public string? Imagen { get; set; }
        public int? IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual Modulo IdModuloNavigation { get; set; } = null!;

        public virtual ICollection<Rol> IdRols { get; set; }
    }
}
