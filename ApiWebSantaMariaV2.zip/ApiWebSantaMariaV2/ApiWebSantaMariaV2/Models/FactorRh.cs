﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class FactorRh
    {
        public FactorRh()
        {
            Pacientes = new HashSet<Paciente>();
        }

        public int IdFactorRh { get; set; }
        public string Descripcion { get; set; } = null!;
        public string Signo { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<Paciente> Pacientes { get; set; }
    }
}
