﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Turno
    {
        public Turno()
        {
            ProgramacionMedicas = new HashSet<ProgramacionMedica>();
        }

        public int IdTurno { get; set; }
        public string Codigo { get; set; } = null!;
        public string Descripcion { get; set; } = null!;
        public string HoraInicio { get; set; } = null!;
        public string HoraFin { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<ProgramacionMedica> ProgramacionMedicas { get; set; }
    }
}
