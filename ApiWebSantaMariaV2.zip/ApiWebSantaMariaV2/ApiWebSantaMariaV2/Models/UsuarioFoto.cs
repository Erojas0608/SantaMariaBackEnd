﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class UsuarioFoto
    {
        public int IdUsuarioFoto { get; set; }
        public int IdUsuario { get; set; }
        public string Foto { get; set; } = null!;
        public int? IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual Usuario IdUsuarioNavigation { get; set; } = null!;
    }
}
