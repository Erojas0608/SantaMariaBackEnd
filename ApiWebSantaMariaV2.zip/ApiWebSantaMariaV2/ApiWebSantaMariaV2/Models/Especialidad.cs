﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Especialidad
    {
        public Especialidad()
        {
            Cita = new HashSet<Citum>();
            ProgramacionMedicas = new HashSet<ProgramacionMedica>();
            Servicios = new HashSet<Servicio>();
        }

        public int IdEspecialidad { get; set; }
        public string Descripcion { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<Citum> Cita { get; set; }
        public virtual ICollection<ProgramacionMedica> ProgramacionMedicas { get; set; }
        public virtual ICollection<Servicio> Servicios { get; set; }
    }
}
