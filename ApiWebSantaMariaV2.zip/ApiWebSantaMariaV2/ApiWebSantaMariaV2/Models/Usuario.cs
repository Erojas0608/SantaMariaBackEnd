﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Usuario
    {
        public Usuario()
        {
            SistemaErrors = new HashSet<SistemaError>();
            UsuarioFotos = new HashSet<UsuarioFoto>();
        }

        public int IdUsuario { get; set; }
        public int IdEmpleado { get; set; }
        public string? CorreoInstitucional { get; set; }
        public string NombreUsuario { get; set; } = null!;
        public string Clave { get; set; } = null!;
        public string? NomUsuarioAd { get; set; }
        public int? IdGrupo { get; set; }
        public string? Anexo { get; set; }
        public bool? Restriccion { get; set; }
        public string? PeriodoInicio { get; set; }
        public string? PeriodoFin { get; set; }
        public bool? RestablecerClave { get; set; }
        public bool VerificarCuenta { get; set; }
        public int? IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual Empleado IdEmpleadoNavigation { get; set; } = null!;
        public virtual Grupo? IdGrupoNavigation { get; set; }
        public virtual ICollection<SistemaError> SistemaErrors { get; set; }
        public virtual ICollection<UsuarioFoto> UsuarioFotos { get; set; }
    }
}
