﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Citum
    {
        public int IdCita { get; set; }
        public DateTime Fecha { get; set; }
        public string HoraInicio { get; set; } = null!;
        public string HoraFin { get; set; } = null!;
        public int IdPaciente { get; set; }
        public int IdMedico { get; set; }
        public int IdEstadoCita { get; set; }
        public int IdEspecialidad { get; set; }
        public int IdServicio { get; set; }
        public int IdProgramacion { get; set; }
        public bool EsAdicional { get; set; }
        public int IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual Especialidad IdEspecialidadNavigation { get; set; } = null!;
        public virtual EstadoCitum IdEstadoCitaNavigation { get; set; } = null!;
        public virtual Medico IdMedicoNavigation { get; set; } = null!;
        public virtual Paciente IdPacienteNavigation { get; set; } = null!;
        public virtual ProgramacionMedica IdProgramacionNavigation { get; set; } = null!;
        public virtual Servicio IdServicioNavigation { get; set; } = null!;
    }
}
