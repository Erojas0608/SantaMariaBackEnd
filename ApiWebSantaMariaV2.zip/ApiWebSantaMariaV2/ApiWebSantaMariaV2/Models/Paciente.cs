﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Paciente
    {
        public Paciente()
        {
            Cita = new HashSet<Citum>();
        }

        public int IdPaciente { get; set; }
        public string? PrimerApellido { get; set; }
        public string? SegundoApellido { get; set; }
        public string? Nombre { get; set; }
        public string NroHistoria { get; set; } = null!;
        public DateTime? FechaNacimiento { get; set; }
        public string? DireccionDomicilio { get; set; }
        public int IdTipoDocIdent { get; set; }
        public string? NroDocumento { get; set; }
        public int? IdEstadoCivil { get; set; }
        public int IdSexo { get; set; }
        public int? IdGradoInstruccion { get; set; }
        public int? IdGrupoSanguineo { get; set; }
        public int? IdFactorRh { get; set; }
        public string? Telefono { get; set; }
        public string? Correo { get; set; }
        public string? NombrePadre { get; set; }
        public string? NombreMadre { get; set; }
        public int? IdUbigeoNac { get; set; }
        public int? IdUbigeoDom { get; set; }
        public int? IdUbigeoProc { get; set; }
        public int? IdOcupacion { get; set; }
        public bool EsReniec { get; set; }
        public string? Observacion { get; set; }
        public int IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual EstadoCivil? IdEstadoCivilNavigation { get; set; }
        public virtual FactorRh? IdFactorRhNavigation { get; set; }
        public virtual GradoInstruccion? IdGradoInstruccionNavigation { get; set; }
        public virtual GrupoSanguineo? IdGrupoSanguineoNavigation { get; set; }
        public virtual Ocupacion? IdOcupacionNavigation { get; set; }
        public virtual Sexo IdSexoNavigation { get; set; } = null!;
        public virtual TipoDocIdent IdTipoDocIdentNavigation { get; set; } = null!;
        public virtual Ubigeo? IdUbigeoDomNavigation { get; set; }
        public virtual Ubigeo? IdUbigeoNacNavigation { get; set; }
        public virtual Ubigeo? IdUbigeoProcNavigation { get; set; }
        public virtual ICollection<Citum> Cita { get; set; }
    }
}
