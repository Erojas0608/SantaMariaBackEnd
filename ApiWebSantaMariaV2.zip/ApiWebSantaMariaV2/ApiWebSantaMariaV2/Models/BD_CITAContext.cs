﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ApiWebSantaMariaV2.Models
{
    public partial class BD_CITAContext : DbContext
    {
        public BD_CITAContext()
        {
        }

        public BD_CITAContext(DbContextOptions<BD_CITAContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Citum> Cita { get; set; } = null!;
        public virtual DbSet<Empleado> Empleados { get; set; } = null!;
        public virtual DbSet<Especialidad> Especialidads { get; set; } = null!;
        public virtual DbSet<EstadoCitum> EstadoCita { get; set; } = null!;
        public virtual DbSet<EstadoCivil> EstadoCivils { get; set; } = null!;
        public virtual DbSet<FactorRh> FactorRhs { get; set; } = null!;
        public virtual DbSet<GradoInstruccion> GradoInstruccions { get; set; } = null!;
        public virtual DbSet<Grupo> Grupos { get; set; } = null!;
        public virtual DbSet<GrupoSanguineo> GrupoSanguineos { get; set; } = null!;
        public virtual DbSet<Medico> Medicos { get; set; } = null!;
        public virtual DbSet<Modulo> Modulos { get; set; } = null!;
        public virtual DbSet<Ocupacion> Ocupacions { get; set; } = null!;
        public virtual DbSet<Paciente> Pacientes { get; set; } = null!;
        public virtual DbSet<ProgramacionMedica> ProgramacionMedicas { get; set; } = null!;
        public virtual DbSet<Rol> Rols { get; set; } = null!;
        public virtual DbSet<Servicio> Servicios { get; set; } = null!;
        public virtual DbSet<Sexo> Sexos { get; set; } = null!;
        public virtual DbSet<Sistema> Sistemas { get; set; } = null!;
        public virtual DbSet<SistemaError> SistemaErrors { get; set; } = null!;
        public virtual DbSet<TipoDocIdent> TipoDocIdents { get; set; } = null!;
        public virtual DbSet<Transaccion> Transaccions { get; set; } = null!;
        public virtual DbSet<Turno> Turnos { get; set; } = null!;
        public virtual DbSet<Ubigeo> Ubigeos { get; set; } = null!;
        public virtual DbSet<Usuario> Usuarios { get; set; } = null!;
        public virtual DbSet<UsuarioFoto> UsuarioFotos { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
                var connectionString = configuration.GetConnectionString("cadenaSql");
                optionsBuilder.UseSqlServer(connectionString);
            }
            //            if (!optionsBuilder.IsConfigured)
            //            {
            //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
            //                optionsBuilder.UseSqlServer("Server=127.0.0.1; DataBase=BD_CITA; Trusted_Connection=True; TrustServerCertificate=True;");
            //            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Citum>(entity =>
            {
                entity.HasKey(e => e.IdCita);

                entity.ToTable("CITA");

                entity.Property(e => e.IdCita).HasColumnName("id_cita");

                entity.Property(e => e.EsAdicional).HasColumnName("es_adicional");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Fecha)
                    .HasColumnType("date")
                    .HasColumnName("fecha");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.HoraFin)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("hora_fin")
                    .IsFixedLength();

                entity.Property(e => e.HoraInicio)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("hora_inicio")
                    .IsFixedLength();

                entity.Property(e => e.IdEspecialidad).HasColumnName("id_especialidad");

                entity.Property(e => e.IdEstadoCita).HasColumnName("id_estado_cita");

                entity.Property(e => e.IdMedico).HasColumnName("id_medico");

                entity.Property(e => e.IdPaciente).HasColumnName("id_paciente");

                entity.Property(e => e.IdProgramacion).HasColumnName("id_programacion");

                entity.Property(e => e.IdServicio).HasColumnName("id_servicio");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.HasOne(d => d.IdEspecialidadNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.IdEspecialidad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CITA_ESPECIALIDAD");

                entity.HasOne(d => d.IdEstadoCitaNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.IdEstadoCita)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CITA_ESTADO_CITA");

                entity.HasOne(d => d.IdMedicoNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.IdMedico)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CITA_MEDICO");

                entity.HasOne(d => d.IdPacienteNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.IdPaciente)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CITA_PACIENTE");

                entity.HasOne(d => d.IdProgramacionNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.IdProgramacion)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CITA_PROGRAMACION_MEDICA");

                entity.HasOne(d => d.IdServicioNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.IdServicio)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CITA_SERVICIO");
            });

            modelBuilder.Entity<Empleado>(entity =>
            {
                entity.HasKey(e => e.IdEmpleado);

                entity.ToTable("EMPLEADO");

                entity.Property(e => e.IdEmpleado).HasColumnName("id_empleado");

                entity.Property(e => e.Correo)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("correo");

                entity.Property(e => e.DireccionDomicilio)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("direccion_domicilio");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaBaja)
                    .HasColumnType("date")
                    .HasColumnName("fecha_baja");

                entity.Property(e => e.FechaIngreso)
                    .HasColumnType("date")
                    .HasColumnName("fecha_ingreso");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdSexo).HasColumnName("id_sexo");

                entity.Property(e => e.IdTipoDocIdent).HasColumnName("id_tipo_doc_ident");

                entity.Property(e => e.IdUbigeoDom).HasColumnName("id_ubigeo_dom");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.Property(e => e.Nombre)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nombre");

                entity.Property(e => e.NroDocumento)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("nro_documento");

                entity.Property(e => e.Observacion)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("observacion");

                entity.Property(e => e.PrimerApellido)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("primer_apellido");

                entity.Property(e => e.SegundoApellido)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("segundo_apellido");

                entity.Property(e => e.Telefono)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("telefono");

                entity.HasOne(d => d.IdSexoNavigation)
                    .WithMany(p => p.Empleados)
                    .HasForeignKey(d => d.IdSexo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EMPLEADO_SEXO");

                entity.HasOne(d => d.IdTipoDocIdentNavigation)
                    .WithMany(p => p.Empleados)
                    .HasForeignKey(d => d.IdTipoDocIdent)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EMPLEADO_TIPO_DOC_IDENT");

                entity.HasOne(d => d.IdUbigeoDomNavigation)
                    .WithMany(p => p.Empleados)
                    .HasForeignKey(d => d.IdUbigeoDom)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EMPLEADO_UBIGEO");
            });

            modelBuilder.Entity<Especialidad>(entity =>
            {
                entity.HasKey(e => e.IdEspecialidad);

                entity.ToTable("ESPECIALIDAD");

                entity.Property(e => e.IdEspecialidad).HasColumnName("id_especialidad");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<EstadoCitum>(entity =>
            {
                entity.HasKey(e => e.IdEstadoCita);

                entity.ToTable("ESTADO_CITA");

                entity.Property(e => e.IdEstadoCita).HasColumnName("id_estado_cita");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<EstadoCivil>(entity =>
            {
                entity.HasKey(e => e.IdEstadoCivil);

                entity.ToTable("ESTADO_CIVIL");

                entity.Property(e => e.IdEstadoCivil).HasColumnName("id_estado_civil");

                entity.Property(e => e.CodigoReniec)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("codigo_reniec")
                    .IsFixedLength();

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<FactorRh>(entity =>
            {
                entity.HasKey(e => e.IdFactorRh);

                entity.ToTable("FACTOR_RH");

                entity.Property(e => e.IdFactorRh).HasColumnName("id_factor_rh");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Signo)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("signo")
                    .IsFixedLength();
            });

            modelBuilder.Entity<GradoInstruccion>(entity =>
            {
                entity.HasKey(e => e.IdGradoInstruccion);

                entity.ToTable("GRADO_INSTRUCCION");

                entity.Property(e => e.IdGradoInstruccion).HasColumnName("id_grado_instruccion");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Grupo>(entity =>
            {
                entity.HasKey(e => e.IdGrupo);

                entity.ToTable("GRUPO", "seguridad");

                entity.Property(e => e.IdGrupo).HasColumnName("id_grupo");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.DescripcionCorta)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("descripcion_corta");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.HasMany(d => d.IdRols)
                    .WithMany(p => p.IdGrupos)
                    .UsingEntity<Dictionary<string, object>>(
                        "Perfil",
                        l => l.HasOne<Rol>().WithMany().HasForeignKey("IdRol").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_PERFIL_ROL"),
                        r => r.HasOne<Grupo>().WithMany().HasForeignKey("IdGrupo").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_PERFIL_GRUPO"),
                        j =>
                        {
                            j.HasKey("IdGrupo", "IdRol");

                            j.ToTable("PERFIL", "seguridad");

                            j.IndexerProperty<int>("IdGrupo").HasColumnName("id_grupo");

                            j.IndexerProperty<int>("IdRol").HasColumnName("id_rol");
                        });
            });

            modelBuilder.Entity<GrupoSanguineo>(entity =>
            {
                entity.HasKey(e => e.IdGrupoSanguineo);

                entity.ToTable("GRUPO_SANGUINEO");

                entity.Property(e => e.IdGrupoSanguineo).HasColumnName("id_grupo_sanguineo");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Medico>(entity =>
            {
                entity.HasKey(e => e.IdMedico);

                entity.ToTable("MEDICO");

                entity.Property(e => e.IdMedico).HasColumnName("id_medico");

                entity.Property(e => e.Colegiatura)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("colegiatura");

                entity.Property(e => e.IdEmpleado).HasColumnName("id_empleado");

                entity.HasOne(d => d.IdEmpleadoNavigation)
                    .WithMany(p => p.Medicos)
                    .HasForeignKey(d => d.IdEmpleado)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MEDICO_EMPLEADO");
            });

            modelBuilder.Entity<Modulo>(entity =>
            {
                entity.HasKey(e => e.IdModulo);

                entity.ToTable("MODULO", "seguridad");

                entity.Property(e => e.IdModulo).HasColumnName("id_modulo");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.DescripcionCorta)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("descripcion_corta");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Icono)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("icono");

                entity.Property(e => e.IdSistema).HasColumnName("id_sistema");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.Property(e => e.Observacion)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("observacion");

                entity.HasOne(d => d.IdSistemaNavigation)
                    .WithMany(p => p.Modulos)
                    .HasForeignKey(d => d.IdSistema)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MODULO_SISTEMA");
            });

            modelBuilder.Entity<Ocupacion>(entity =>
            {
                entity.HasKey(e => e.IdOcupacion);

                entity.ToTable("OCUPACION");

                entity.Property(e => e.IdOcupacion).HasColumnName("id_ocupacion");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Paciente>(entity =>
            {
                entity.HasKey(e => e.IdPaciente);

                entity.ToTable("PACIENTE");

                entity.Property(e => e.IdPaciente).HasColumnName("id_paciente");

                entity.Property(e => e.Correo)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("correo");

                entity.Property(e => e.DireccionDomicilio)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("direccion_domicilio");

                entity.Property(e => e.EsReniec).HasColumnName("es_reniec");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaNacimiento)
                    .HasColumnType("date")
                    .HasColumnName("fecha_nacimiento");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdEstadoCivil).HasColumnName("id_estado_civil");

                entity.Property(e => e.IdFactorRh).HasColumnName("id_factor_rh");

                entity.Property(e => e.IdGradoInstruccion).HasColumnName("id_grado_instruccion");

                entity.Property(e => e.IdGrupoSanguineo).HasColumnName("id_grupo_sanguineo");

                entity.Property(e => e.IdOcupacion).HasColumnName("id_ocupacion");

                entity.Property(e => e.IdSexo).HasColumnName("id_sexo");

                entity.Property(e => e.IdTipoDocIdent).HasColumnName("id_tipo_doc_ident");

                entity.Property(e => e.IdUbigeoDom).HasColumnName("id_ubigeo_dom");

                entity.Property(e => e.IdUbigeoNac).HasColumnName("id_ubigeo_nac");

                entity.Property(e => e.IdUbigeoProc).HasColumnName("id_ubigeo_proc");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.Property(e => e.Nombre)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nombre");

                entity.Property(e => e.NombreMadre)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nombre_madre");

                entity.Property(e => e.NombrePadre)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nombre_padre");

                entity.Property(e => e.NroDocumento)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("nro_documento");

                entity.Property(e => e.NroHistoria)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("nro_historia");

                entity.Property(e => e.Observacion)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("observacion");

                entity.Property(e => e.PrimerApellido)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("primer_apellido");

                entity.Property(e => e.SegundoApellido)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("segundo_apellido");

                entity.Property(e => e.Telefono)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("telefono");

                entity.HasOne(d => d.IdEstadoCivilNavigation)
                    .WithMany(p => p.Pacientes)
                    .HasForeignKey(d => d.IdEstadoCivil)
                    .HasConstraintName("FK_PACIENTE_ESTADO_CIVIL");

                entity.HasOne(d => d.IdFactorRhNavigation)
                    .WithMany(p => p.Pacientes)
                    .HasForeignKey(d => d.IdFactorRh)
                    .HasConstraintName("FK_PACIENTE_FACTOR_RH");

                entity.HasOne(d => d.IdGradoInstruccionNavigation)
                    .WithMany(p => p.Pacientes)
                    .HasForeignKey(d => d.IdGradoInstruccion)
                    .HasConstraintName("FK_PACIENTE_GRADO_INSTRUCCION");

                entity.HasOne(d => d.IdGrupoSanguineoNavigation)
                    .WithMany(p => p.Pacientes)
                    .HasForeignKey(d => d.IdGrupoSanguineo)
                    .HasConstraintName("FK_PACIENTE_GRUPO_SANGUINEO");

                entity.HasOne(d => d.IdOcupacionNavigation)
                    .WithMany(p => p.Pacientes)
                    .HasForeignKey(d => d.IdOcupacion)
                    .HasConstraintName("FK_PACIENTE_OCUPACION");

                entity.HasOne(d => d.IdSexoNavigation)
                    .WithMany(p => p.Pacientes)
                    .HasForeignKey(d => d.IdSexo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PACIENTE_SEXO");

                entity.HasOne(d => d.IdTipoDocIdentNavigation)
                    .WithMany(p => p.Pacientes)
                    .HasForeignKey(d => d.IdTipoDocIdent)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PACIENTE_TIPO_DOC_IDENT");

                entity.HasOne(d => d.IdUbigeoDomNavigation)
                    .WithMany(p => p.PacienteIdUbigeoDomNavigations)
                    .HasForeignKey(d => d.IdUbigeoDom)
                    .HasConstraintName("FK_PACIENTE_UBIGEO_II");

                entity.HasOne(d => d.IdUbigeoNacNavigation)
                    .WithMany(p => p.PacienteIdUbigeoNacNavigations)
                    .HasForeignKey(d => d.IdUbigeoNac)
                    .HasConstraintName("FK_PACIENTE_UBIGEO_I");

                entity.HasOne(d => d.IdUbigeoProcNavigation)
                    .WithMany(p => p.PacienteIdUbigeoProcNavigations)
                    .HasForeignKey(d => d.IdUbigeoProc)
                    .HasConstraintName("FK_PACIENTE_UBIGEO_III");
            });

            modelBuilder.Entity<ProgramacionMedica>(entity =>
            {
                entity.HasKey(e => e.IdProgramacion);

                entity.ToTable("PROGRAMACION_MEDICA");

                entity.Property(e => e.IdProgramacion).HasColumnName("id_programacion");

                entity.Property(e => e.Color)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("color");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Fecha)
                    .HasColumnType("date")
                    .HasColumnName("fecha");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.HoraFin)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("hora_fin")
                    .IsFixedLength();

                entity.Property(e => e.HoraFinProg)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("hora_fin_prog")
                    .IsFixedLength();

                entity.Property(e => e.HoraInicio)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("hora_inicio")
                    .IsFixedLength();

                entity.Property(e => e.IdEspecialidad).HasColumnName("id_especialidad");

                entity.Property(e => e.IdMedico).HasColumnName("id_medico");

                entity.Property(e => e.IdServicio).HasColumnName("id_servicio");

                entity.Property(e => e.IdTurno).HasColumnName("id_turno");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.Property(e => e.RatioAtencion).HasColumnName("ratio_atencion");

                entity.HasOne(d => d.IdEspecialidadNavigation)
                    .WithMany(p => p.ProgramacionMedicas)
                    .HasForeignKey(d => d.IdEspecialidad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PROGRAMACION_MEDICA_ESPECIALIDAD");

                entity.HasOne(d => d.IdMedicoNavigation)
                    .WithMany(p => p.ProgramacionMedicas)
                    .HasForeignKey(d => d.IdMedico)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PROGRAMACION_MEDICA_MEDICO");

                entity.HasOne(d => d.IdServicioNavigation)
                    .WithMany(p => p.ProgramacionMedicas)
                    .HasForeignKey(d => d.IdServicio)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PROGRAMACION_MEDICA_SERVICIO");

                entity.HasOne(d => d.IdTurnoNavigation)
                    .WithMany(p => p.ProgramacionMedicas)
                    .HasForeignKey(d => d.IdTurno)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PROGRAMACION_MEDICA_TURNO");
            });

            modelBuilder.Entity<Rol>(entity =>
            {
                entity.HasKey(e => e.IdRol);

                entity.ToTable("ROL", "seguridad");

                entity.Property(e => e.IdRol).HasColumnName("id_rol");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.DescripcionCorta)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("descripcion_corta");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");
            });

            modelBuilder.Entity<Servicio>(entity =>
            {
                entity.HasKey(e => e.IdServicio);

                entity.ToTable("SERVICIO");

                entity.Property(e => e.IdServicio).HasColumnName("id_servicio");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdEspecialidad).HasColumnName("id_especialidad");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.Property(e => e.RatioAtencion).HasColumnName("ratio_atencion");

                entity.HasOne(d => d.IdEspecialidadNavigation)
                    .WithMany(p => p.Servicios)
                    .HasForeignKey(d => d.IdEspecialidad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SERVICIO_ESPECIALIDAD");
            });

            modelBuilder.Entity<Sexo>(entity =>
            {
                entity.HasKey(e => e.IdSexo);

                entity.ToTable("SEXO");

                entity.Property(e => e.IdSexo).HasColumnName("id_sexo");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Sistema>(entity =>
            {
                entity.HasKey(e => e.IdSistema);

                entity.ToTable("SISTEMA", "seguridad");

                entity.Property(e => e.IdSistema).HasColumnName("id_sistema");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.Property(e => e.Logo)
                    .IsUnicode(false)
                    .HasColumnName("logo");

                entity.Property(e => e.Membrete)
                    .IsUnicode(false)
                    .HasColumnName("membrete");

                entity.Property(e => e.Observacion)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("observacion");

                entity.Property(e => e.PerfilControlado).HasColumnName("perfil_controlado");

                entity.Property(e => e.RutaUrl)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("ruta_url");

                entity.Property(e => e.Sigla)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("sigla");
            });

            modelBuilder.Entity<SistemaError>(entity =>
            {
                entity.HasKey(e => e.IdError);

                entity.ToTable("SISTEMA_ERROR", "seguridad");

                entity.Property(e => e.IdError).HasColumnName("id_error");

                entity.Property(e => e.Accion)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("accion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdUsuario).HasColumnName("id_usuario");

                entity.Property(e => e.Modulo)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("modulo");

                entity.Property(e => e.Observacion)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("observacion");

                entity.Property(e => e.Transaccion)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("transaccion");

                entity.HasOne(d => d.IdUsuarioNavigation)
                    .WithMany(p => p.SistemaErrors)
                    .HasForeignKey(d => d.IdUsuario)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SISTEMA_ERROR_USUARIO");
            });

            modelBuilder.Entity<TipoDocIdent>(entity =>
            {
                entity.HasKey(e => e.IdTipoDocIdent);

                entity.ToTable("TIPO_DOC_IDENT");

                entity.Property(e => e.IdTipoDocIdent).HasColumnName("id_tipo_doc_ident");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Observacion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("observacion");
            });

            modelBuilder.Entity<Transaccion>(entity =>
            {
                entity.HasKey(e => e.IdTransaccion);

                entity.ToTable("TRANSACCION", "seguridad");

                entity.Property(e => e.IdTransaccion).HasColumnName("id_transaccion");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.DescripcionCorta)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("descripcion_corta");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Icono)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("icono");

                entity.Property(e => e.IdModulo).HasColumnName("id_modulo");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.Property(e => e.Imagen)
                    .IsUnicode(false)
                    .HasColumnName("imagen");

                entity.Property(e => e.Observacion)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("observacion");

                entity.Property(e => e.RutaUrl)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("ruta_url");

                entity.HasOne(d => d.IdModuloNavigation)
                    .WithMany(p => p.Transaccions)
                    .HasForeignKey(d => d.IdModulo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TRANSACCION_MODULO");

                entity.HasMany(d => d.IdRols)
                    .WithMany(p => p.IdTransaccions)
                    .UsingEntity<Dictionary<string, object>>(
                        "Permiso",
                        l => l.HasOne<Rol>().WithMany().HasForeignKey("IdRol").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_PERMISO_ROL"),
                        r => r.HasOne<Transaccion>().WithMany().HasForeignKey("IdTransaccion").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_PERMISO_TRANSACCION"),
                        j =>
                        {
                            j.HasKey("IdTransaccion", "IdRol");

                            j.ToTable("PERMISO", "seguridad");

                            j.IndexerProperty<int>("IdTransaccion").HasColumnName("id_transaccion");

                            j.IndexerProperty<int>("IdRol").HasColumnName("id_rol");
                        });
            });

            modelBuilder.Entity<Turno>(entity =>
            {
                entity.HasKey(e => e.IdTurno);

                entity.ToTable("TURNO");

                entity.Property(e => e.IdTurno).HasColumnName("id_turno");

                entity.Property(e => e.Codigo)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("codigo");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.HoraFin)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("hora_fin")
                    .IsFixedLength();

                entity.Property(e => e.HoraInicio)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("hora_inicio")
                    .IsFixedLength();
            });

            modelBuilder.Entity<Ubigeo>(entity =>
            {
                entity.HasKey(e => e.IdUbigeo);

                entity.ToTable("UBIGEO");

                entity.Property(e => e.IdUbigeo).HasColumnName("id_ubigeo");

                entity.Property(e => e.CodDepInei)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("cod_dep_inei")
                    .IsFixedLength();

                entity.Property(e => e.CodDepReniec)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("cod_dep_reniec")
                    .IsFixedLength();

                entity.Property(e => e.CodDistInei)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("cod_dist_inei")
                    .IsFixedLength();

                entity.Property(e => e.CodDistReniec)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("cod_dist_reniec")
                    .IsFixedLength();

                entity.Property(e => e.CodProvInei)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("cod_prov_inei")
                    .IsFixedLength();

                entity.Property(e => e.CodProvReniec)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("cod_prov_reniec")
                    .IsFixedLength();

                entity.Property(e => e.Departamento)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("departamento");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("descripcion");

                entity.Property(e => e.Distrito)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("distrito");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Provincia)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("provincia");

                entity.Property(e => e.UbigeoInei)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("ubigeo_inei")
                    .IsFixedLength();

                entity.Property(e => e.UbigeoReniec)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("ubigeo_reniec")
                    .IsFixedLength();
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.HasKey(e => e.IdUsuario);

                entity.ToTable("USUARIO", "seguridad");

                entity.Property(e => e.IdUsuario).HasColumnName("id_usuario");

                entity.Property(e => e.Anexo)
                    .HasMaxLength(11)
                    .IsUnicode(false)
                    .HasColumnName("anexo");

                entity.Property(e => e.Clave)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("clave");

                entity.Property(e => e.CorreoInstitucional)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("correo_institucional");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdEmpleado).HasColumnName("id_empleado");

                entity.Property(e => e.IdGrupo).HasColumnName("id_grupo");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.Property(e => e.NomUsuarioAd)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nom_usuario_ad");

                entity.Property(e => e.NombreUsuario)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nombre_usuario");

                entity.Property(e => e.PeriodoFin)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("periodo_fin")
                    .IsFixedLength();

                entity.Property(e => e.PeriodoInicio)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("periodo_inicio")
                    .IsFixedLength();

                entity.Property(e => e.RestablecerClave)
                    .IsRequired()
                    .HasColumnName("restablecer_clave")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Restriccion)
                    .IsRequired()
                    .HasColumnName("restriccion")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.VerificarCuenta).HasColumnName("verificar_cuenta");

                entity.HasOne(d => d.IdEmpleadoNavigation)
                    .WithMany(p => p.Usuarios)
                    .HasForeignKey(d => d.IdEmpleado)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_USUARIO_EMPLEADO");

                entity.HasOne(d => d.IdGrupoNavigation)
                    .WithMany(p => p.Usuarios)
                    .HasForeignKey(d => d.IdGrupo)
                    .HasConstraintName("FK_USUARIO_GRUPO");
            });

            modelBuilder.Entity<UsuarioFoto>(entity =>
            {
                entity.HasKey(e => e.IdUsuarioFoto);

                entity.ToTable("USUARIO_FOTO", "seguridad");

                entity.Property(e => e.IdUsuarioFoto).HasColumnName("id_usuario_foto");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("estado")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.FechaModifica)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_modifica");

                entity.Property(e => e.FechaRegistro)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_registro")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Foto)
                    .IsUnicode(false)
                    .HasColumnName("foto");

                entity.Property(e => e.IdUsuario).HasColumnName("id_usuario");

                entity.Property(e => e.IdUsuarioModifica).HasColumnName("id_usuario_modifica");

                entity.Property(e => e.IdUsuarioRegistro).HasColumnName("id_usuario_registro");

                entity.HasOne(d => d.IdUsuarioNavigation)
                    .WithMany(p => p.UsuarioFotos)
                    .HasForeignKey(d => d.IdUsuario)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_USUARIO_FOTO_USUARIO");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
