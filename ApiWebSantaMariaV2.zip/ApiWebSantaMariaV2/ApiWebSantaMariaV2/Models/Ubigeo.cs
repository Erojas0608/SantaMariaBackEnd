﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Ubigeo
    {
        public Ubigeo()
        {
            Empleados = new HashSet<Empleado>();
            PacienteIdUbigeoDomNavigations = new HashSet<Paciente>();
            PacienteIdUbigeoNacNavigations = new HashSet<Paciente>();
            PacienteIdUbigeoProcNavigations = new HashSet<Paciente>();
        }

        public int IdUbigeo { get; set; }
        public string UbigeoReniec { get; set; } = null!;
        public string UbigeoInei { get; set; } = null!;
        public string Departamento { get; set; } = null!;
        public string Provincia { get; set; } = null!;
        public string Distrito { get; set; } = null!;
        public string Descripcion { get; set; } = null!;
        public string CodDepInei { get; set; } = null!;
        public string CodProvInei { get; set; } = null!;
        public string CodDistInei { get; set; } = null!;
        public string CodDepReniec { get; set; } = null!;
        public string CodProvReniec { get; set; } = null!;
        public string CodDistReniec { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<Empleado> Empleados { get; set; }
        public virtual ICollection<Paciente> PacienteIdUbigeoDomNavigations { get; set; }
        public virtual ICollection<Paciente> PacienteIdUbigeoNacNavigations { get; set; }
        public virtual ICollection<Paciente> PacienteIdUbigeoProcNavigations { get; set; }
    }
}
