﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Medico
    {
        public Medico()
        {
            Cita = new HashSet<Citum>();
            ProgramacionMedicas = new HashSet<ProgramacionMedica>();
        }

        public int IdMedico { get; set; }
        public int IdEmpleado { get; set; }
        public string Colegiatura { get; set; } = null!;

        public virtual Empleado IdEmpleadoNavigation { get; set; } = null!;
        public virtual ICollection<Citum> Cita { get; set; }
        public virtual ICollection<ProgramacionMedica> ProgramacionMedicas { get; set; }
    }
}
