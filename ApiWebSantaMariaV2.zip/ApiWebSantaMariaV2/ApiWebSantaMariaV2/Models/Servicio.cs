﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Servicio
    {
        public Servicio()
        {
            Cita = new HashSet<Citum>();
            ProgramacionMedicas = new HashSet<ProgramacionMedica>();
        }

        public int IdServicio { get; set; }
        public string Descripcion { get; set; } = null!;
        public int IdEspecialidad { get; set; }
        public byte RatioAtencion { get; set; }
        public int IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual Especialidad IdEspecialidadNavigation { get; set; } = null!;
        public virtual ICollection<Citum> Cita { get; set; }
        public virtual ICollection<ProgramacionMedica> ProgramacionMedicas { get; set; }
    }
}
