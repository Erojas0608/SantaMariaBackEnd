﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class TipoDocIdent
    {
        public TipoDocIdent()
        {
            Empleados = new HashSet<Empleado>();
            Pacientes = new HashSet<Paciente>();
        }

        public int IdTipoDocIdent { get; set; }
        public string Descripcion { get; set; } = null!;
        public string Observacion { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<Empleado> Empleados { get; set; }
        public virtual ICollection<Paciente> Pacientes { get; set; }
    }
}
