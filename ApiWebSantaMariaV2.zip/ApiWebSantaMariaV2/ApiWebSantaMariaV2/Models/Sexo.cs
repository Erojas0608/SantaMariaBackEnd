﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Sexo
    {
        public Sexo()
        {
            Empleados = new HashSet<Empleado>();
            Pacientes = new HashSet<Paciente>();
        }

        public int IdSexo { get; set; }
        public string Descripcion { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<Empleado> Empleados { get; set; }
        public virtual ICollection<Paciente> Pacientes { get; set; }
    }
}
