﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Rol
    {
        public Rol()
        {
            IdGrupos = new HashSet<Grupo>();
            IdTransaccions = new HashSet<Transaccion>();
        }

        public int IdRol { get; set; }
        public string Descripcion { get; set; } = null!;
        public string DescripcionCorta { get; set; } = null!;
        public int? IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual ICollection<Grupo> IdGrupos { get; set; }
        public virtual ICollection<Transaccion> IdTransaccions { get; set; }
    }
}
