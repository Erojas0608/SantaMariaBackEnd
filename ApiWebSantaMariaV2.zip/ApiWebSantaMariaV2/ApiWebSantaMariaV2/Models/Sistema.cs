﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Sistema
    {
        public Sistema()
        {
            Modulos = new HashSet<Modulo>();
        }

        public int IdSistema { get; set; }
        public string Descripcion { get; set; } = null!;
        public string Sigla { get; set; } = null!;
        public string? Observacion { get; set; }
        public string RutaUrl { get; set; } = null!;
        public string? Logo { get; set; }
        public string? Membrete { get; set; }
        public bool PerfilControlado { get; set; }
        public int? IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual ICollection<Modulo> Modulos { get; set; }
    }
}
