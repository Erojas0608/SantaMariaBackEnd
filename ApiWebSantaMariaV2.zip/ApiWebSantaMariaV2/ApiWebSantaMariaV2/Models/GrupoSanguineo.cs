﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class GrupoSanguineo
    {
        public GrupoSanguineo()
        {
            Pacientes = new HashSet<Paciente>();
        }

        public int IdGrupoSanguineo { get; set; }
        public string Descripcion { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<Paciente> Pacientes { get; set; }
    }
}
