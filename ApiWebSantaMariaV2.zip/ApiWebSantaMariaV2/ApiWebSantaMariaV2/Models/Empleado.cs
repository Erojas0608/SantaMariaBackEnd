﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Empleado
    {
        public Empleado()
        {
            Medicos = new HashSet<Medico>();
            Usuarios = new HashSet<Usuario>();
        }

        public int IdEmpleado { get; set; }
        public string? PrimerApellido { get; set; }
        public string? SegundoApellido { get; set; }
        public string? Nombre { get; set; }
        public int IdTipoDocIdent { get; set; }
        public string? NroDocumento { get; set; }
        public int IdSexo { get; set; }
        public string? DireccionDomicilio { get; set; }
        public int IdUbigeoDom { get; set; }
        public string? Telefono { get; set; }
        public string? Correo { get; set; }
        public DateTime FechaIngreso { get; set; }
        public DateTime? FechaBaja { get; set; }
        public string? Observacion { get; set; }
        public int IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual Sexo IdSexoNavigation { get; set; } = null!;
        public virtual TipoDocIdent IdTipoDocIdentNavigation { get; set; } = null!;
        public virtual Ubigeo IdUbigeoDomNavigation { get; set; } = null!;
        public virtual ICollection<Medico> Medicos { get; set; }
        public virtual ICollection<Usuario> Usuarios { get; set; }
    }
}
