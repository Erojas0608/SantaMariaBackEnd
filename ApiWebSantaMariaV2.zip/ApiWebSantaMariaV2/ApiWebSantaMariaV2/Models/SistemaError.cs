﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class SistemaError
    {
        public int IdError { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int IdUsuario { get; set; }
        public string Accion { get; set; } = null!;
        public string Modulo { get; set; } = null!;
        public string Transaccion { get; set; } = null!;
        public string Observacion { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual Usuario IdUsuarioNavigation { get; set; } = null!;
    }
}
