﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class EstadoCivil
    {
        public EstadoCivil()
        {
            Pacientes = new HashSet<Paciente>();
        }

        public int IdEstadoCivil { get; set; }
        public string CodigoReniec { get; set; } = null!;
        public string Descripcion { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<Paciente> Pacientes { get; set; }
    }
}
