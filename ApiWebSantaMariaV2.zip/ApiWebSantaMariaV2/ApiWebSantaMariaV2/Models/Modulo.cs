﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Modulo
    {
        public Modulo()
        {
            Transaccions = new HashSet<Transaccion>();
        }

        public int IdModulo { get; set; }
        public string Descripcion { get; set; } = null!;
        public string DescripcionCorta { get; set; } = null!;
        public string? Observacion { get; set; }
        public string? Icono { get; set; }
        public int IdSistema { get; set; }
        public int? IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual Sistema IdSistemaNavigation { get; set; } = null!;
        public virtual ICollection<Transaccion> Transaccions { get; set; }
    }
}
