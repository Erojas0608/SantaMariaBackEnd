﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class EstadoCivilResponse
    {
        public List<EstadoCivil> message { get; set; }
        public string status { get; set; }
    }
}
