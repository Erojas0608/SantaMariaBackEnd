﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class FactorRhResponse
    {
        public List<FactorRh> message { get; set; }
        public string status { get; set; }
    }
}
