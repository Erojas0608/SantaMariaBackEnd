﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class PacienteResponse
    {
        public List<Paciente> message { get; set; }
        public string status { get; set; }
    }
}
