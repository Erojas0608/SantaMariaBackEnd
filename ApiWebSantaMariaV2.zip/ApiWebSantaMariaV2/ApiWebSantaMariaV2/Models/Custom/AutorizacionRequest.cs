﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class AutorizacionRequest
    {
        public string NombreUsuario { get; set; }
        public string Clave { get; set; }
    }
}
