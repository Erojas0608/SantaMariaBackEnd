﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class TipoDocIdentResponse
    {
        public List<TipoDocIdent> message { get; set; }
        public string status { get; set; }
    }
}
