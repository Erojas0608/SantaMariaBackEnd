﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class JsonResponse
    {
        public bool Resultado { get; set; }
        public string Msg { get; set; }
    }
}
