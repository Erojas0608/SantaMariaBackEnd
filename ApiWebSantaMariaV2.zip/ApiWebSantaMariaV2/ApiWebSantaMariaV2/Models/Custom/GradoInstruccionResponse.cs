﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class GradoInstruccionResponse
    {
        public List<GradoInstruccion> message { get; set; }
        public string status { get; set; }
    }
}
