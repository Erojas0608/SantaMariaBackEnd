﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class OcupacionResponse
    {
        public List<Ocupacion> message { get; set; }
        public string status { get; set; }
    }
}
