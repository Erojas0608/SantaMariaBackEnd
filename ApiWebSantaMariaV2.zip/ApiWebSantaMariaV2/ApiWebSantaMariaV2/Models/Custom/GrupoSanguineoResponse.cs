﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class GrupoSanguineoResponse
    {
        public List<GrupoSanguineo> message { get; set; }
        public string status { get; set; }
    }
}
