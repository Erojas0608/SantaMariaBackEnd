﻿namespace ApiWebSantaMariaV2.Models.Custom
{
    public class PacienteRequest
    {
        public int IdPaciente { get; set; }
        public string PrimerApellido { get; set; }
        public string SegundoApellido { get; set; }
        public string Nombre { get; set; }
        public string NroHistoria { get; set; }
        public string FechaNacimiento { get; set; }
        public string DireccionDomicilio { get; set; }
        public int IdTipoDocIdent { get; set; }
        public string NroDocumento { get; set; }
        public int IdEstadoCivil { get; set; }
        public int IdSexo { get; set; }
        public int IdGradoInstruccion { get; set; }
        public int IdGrupoSanguineo { get; set; }
        public int IdFactorRh { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public string NombrePadre { get; set; }
        public string NombreMadre { get; set; }
        public int IdUbigeoDom { get; set; }
        public int IdOcupacion { get; set; }
        public bool EsReniec { get; set; }
        public string Observacion { get; set; }
        public int IdUsuarioModifica { get; set; }
        public int IdUsuarioRegistro { get; set; }
        public bool Estado { get; set; }
    }
}
