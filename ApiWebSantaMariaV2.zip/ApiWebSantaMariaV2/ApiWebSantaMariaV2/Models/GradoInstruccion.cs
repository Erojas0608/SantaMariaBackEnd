﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class GradoInstruccion
    {
        public GradoInstruccion()
        {
            Pacientes = new HashSet<Paciente>();
        }

        public int IdGradoInstruccion { get; set; }
        public string Descripcion { get; set; } = null!;
        public bool? Estado { get; set; }

        public virtual ICollection<Paciente> Pacientes { get; set; }
    }
}
