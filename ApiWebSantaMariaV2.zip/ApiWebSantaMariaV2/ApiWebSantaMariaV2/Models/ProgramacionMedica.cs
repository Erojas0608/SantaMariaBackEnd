﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class ProgramacionMedica
    {
        public ProgramacionMedica()
        {
            Cita = new HashSet<Citum>();
        }

        public int IdProgramacion { get; set; }
        public int IdMedico { get; set; }
        public DateTime Fecha { get; set; }
        public string HoraInicio { get; set; } = null!;
        public string HoraFin { get; set; } = null!;
        public string Descripcion { get; set; } = null!;
        public int IdTurno { get; set; }
        public int IdEspecialidad { get; set; }
        public int IdServicio { get; set; }
        public string Color { get; set; } = null!;
        public byte RatioAtencion { get; set; }
        public string HoraFinProg { get; set; } = null!;
        public int IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual Especialidad IdEspecialidadNavigation { get; set; } = null!;
        public virtual Medico IdMedicoNavigation { get; set; } = null!;
        public virtual Servicio IdServicioNavigation { get; set; } = null!;
        public virtual Turno IdTurnoNavigation { get; set; } = null!;
        public virtual ICollection<Citum> Cita { get; set; }
    }
}
