﻿using System;
using System.Collections.Generic;

namespace ApiWebSantaMariaV2.Models
{
    public partial class Grupo
    {
        public Grupo()
        {
            Usuarios = new HashSet<Usuario>();
            IdRols = new HashSet<Rol>();
        }

        public int IdGrupo { get; set; }
        public string Descripcion { get; set; } = null!;
        public string DescripcionCorta { get; set; } = null!;
        public int? IdUsuarioRegistro { get; set; }
        public DateTime FechaRegistro { get; set; }
        public int? IdUsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
        public bool? Estado { get; set; }

        public virtual ICollection<Usuario> Usuarios { get; set; }

        public virtual ICollection<Rol> IdRols { get; set; }
    }
}
