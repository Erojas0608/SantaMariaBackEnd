﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;
using ApiWebSantaMariaV2.Negocio;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiWebSantaMariaV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstadoCivilController : ControllerBase
    {
        private readonly IEstadoCivilService service = new EstadoCivilService(new BD_CITAContext());

        [Authorize]
        [HttpGet]
        [Route("Lista")]
        public async Task<IActionResult> Lista()
        {
            var resultado_autorizacion = await service.Listar();
            if (resultado_autorizacion == null)
            {
                return NotFound();
            }
            return Ok(resultado_autorizacion);
        }
    }
}
