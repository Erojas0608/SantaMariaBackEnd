﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using ApiWebSantaMariaV2.Models.Custom;
using ApiWebSantaMariaV2.Negocio;
using ApiWebSantaMariaV2.Models;
using Microsoft.Extensions.Configuration;

namespace ApiWebSantaMariaV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly IConfiguration configuracion;
        private readonly IAutorizacionService autorizacionService = new AutorizacionService(new BD_CITAContext());

        public UsuarioController(IConfiguration configuracion)
        {
            this.configuracion = configuracion;
        }

        [HttpPost]
        [Route("Autenticar")]
        public async Task<IActionResult> Autenticar([FromBody] AutorizacionRequest autorizacion) { 
            var resultado_autorizacion = await autorizacionService.DevolverToken(autorizacion);
            if (resultado_autorizacion==null)
            {
                return Unauthorized();
            }

            return Ok(resultado_autorizacion);
        }

    }
}
