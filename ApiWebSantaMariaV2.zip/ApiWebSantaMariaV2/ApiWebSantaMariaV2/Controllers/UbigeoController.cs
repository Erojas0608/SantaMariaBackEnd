﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Negocio;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiWebSantaMariaV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UbigeoController : ControllerBase
    {
        private readonly IUbigeoService service = new UbigeoService(new BD_CITAContext());

        [HttpGet]
        [Authorize]
        [Route("Lista")]
        public async Task<IActionResult> Lista() {
            var lista = await service.Listar();
            return lista == null ? NotFound() : Ok(lista);
        }
    }
}
