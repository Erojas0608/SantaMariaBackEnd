﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Negocio;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiWebSantaMariaV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GrupoSanguineoController : ControllerBase
    {
        private readonly IGrupoSanguineoService service = new GrupoSanguineoService(new BD_CITAContext());
        [Authorize]
        [HttpGet]
        [Route("Lista")]
        public async Task<IActionResult> Lista() {
            var lista = await service.Listar();
            if (lista== null)
            {
                return NotFound();
            }
            return Ok(lista);
        }
    }
}
