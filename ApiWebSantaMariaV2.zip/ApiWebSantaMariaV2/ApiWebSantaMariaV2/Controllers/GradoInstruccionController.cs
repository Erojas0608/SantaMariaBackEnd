﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Negocio;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiWebSantaMariaV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GradoInstruccionController : ControllerBase
    {
        private readonly IGradoInstruccionService servicio= new GradoInstruccionService(new BD_CITAContext());

        [Authorize]
        [HttpGet]
        [Route("Lista")]
        public async Task<IActionResult> Lista()
        {
            var resultado_autorizacion = await servicio.Listar();
            if (resultado_autorizacion == null)
            {
                return NotFound();
            }
            return Ok(resultado_autorizacion);
        }
    }
}
