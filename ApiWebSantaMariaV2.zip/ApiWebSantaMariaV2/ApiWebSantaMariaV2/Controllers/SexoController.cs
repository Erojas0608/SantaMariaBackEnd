﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Negocio;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;

namespace ApiWebSantaMariaV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SexoController : ControllerBase
    {
        private readonly ISexoService service = new SexoService(new BD_CITAContext());

        [HttpGet]
        [Authorize]
        [Route("Lista")]
        public async Task<IActionResult> Lista() {
            var lista = await service.Listar();
            return lista==null ? NotFound() : Ok(lista);
        }
    }
}
