﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class PacienteService: IPacienteService
    {
        private readonly BD_CITAContext context;

        public PacienteService(BD_CITAContext context)
        {
            this.context = context;
        }

        public async Task<PacienteResponse> Listar()
        {
            var lista = context.Pacientes.ToList();
            return new PacienteResponse() {message=lista,status="Ok" };
        }

        public async Task<JsonResponse> RegistrarPaciente(PacienteRequest request)
        {
            Paciente paciente = new Paciente();
            try
            {
                var nacimiento = request.FechaNacimiento.Split("-");
                paciente.PrimerApellido = request.PrimerApellido;
                paciente.SegundoApellido = request.SegundoApellido;
                paciente.Nombre = request.Nombre;
                paciente.NroHistoria = request.NroHistoria;
                paciente.FechaNacimiento = new DateTime(Int32.Parse(nacimiento[0].ToString()), Int32.Parse(nacimiento[1].ToString()), Int32.Parse(nacimiento[2].ToString()), 0, 0, 0); 
                paciente.DireccionDomicilio = request.DireccionDomicilio;
                paciente.IdTipoDocIdent = request.IdTipoDocIdent; 
                paciente.NroDocumento = request.NroDocumento;
                paciente.IdEstadoCivil = request.IdEstadoCivil;
                paciente.IdSexo = request.IdSexo;
                paciente.IdGradoInstruccion = request.IdGradoInstruccion;
                paciente.IdGrupoSanguineo = request.IdGrupoSanguineo;
                paciente.IdFactorRh = request.IdFactorRh;
                paciente.Telefono = request.Telefono;
                paciente.Correo = request.Correo;
                paciente.NombrePadre = request.NombrePadre;
                paciente.NombreMadre= request.NombreMadre;
                paciente.IdUbigeoDom = request.IdUbigeoDom;
                paciente.IdOcupacion = request.IdOcupacion;
                paciente.EsReniec = request.EsReniec;
                paciente.Observacion= request.Observacion;
                paciente.IdUsuarioRegistro = request.IdUsuarioRegistro;
                paciente.FechaRegistro = DateTime.Now;
                paciente.Estado= request.Estado;
                await context.Pacientes.AddAsync(paciente);
                await context.SaveChangesAsync();
                return new JsonResponse() { Msg = "Paciente "+paciente.PrimerApellido+" "+paciente.SegundoApellido+", "+paciente.Nombre+" registrado exitosamente", Resultado = true };
            }
            catch (Exception ex)
            {

                return new JsonResponse() {Msg=ex.Message,Resultado=false};
            }
        }
    }
}
