﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class GradoInstruccionService : IGradoInstruccionService
    {
        private readonly BD_CITAContext context;

        public GradoInstruccionService(BD_CITAContext context)
        {
            this.context = context;
        }

        public async Task<GradoInstruccionResponse> Listar()
        {
            var lista = context.GradoInstruccions.ToList();
            return new GradoInstruccionResponse() { message = lista, status = "Ok" };
        }
    }
}
