﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc;

namespace ApiWebSantaMariaV2.Negocio
{
    public class AutorizacionService : IAutorizacionService
    {
        private readonly BD_CITAContext context;
        
        public AutorizacionService(BD_CITAContext context)
        {
            this.context = context;
        }

        private string GenerarToken(string idUsuario) {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
            var key = configuration.GetValue<string>("JwtSettings:key");
            var keyBytes = Encoding.ASCII.GetBytes(key);

            var claims = new ClaimsIdentity();
            claims.AddClaim(new Claim(ClaimTypes.NameIdentifier, idUsuario));

            var credencialesToken = new SigningCredentials(
                new SymmetricSecurityKey(keyBytes),
                SecurityAlgorithms.HmacSha256Signature
                );

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = claims,
                Expires = DateTime.UtcNow.AddHours(24),
                SigningCredentials = credencialesToken
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenConfig = tokenHandler.CreateToken(tokenDescriptor);

            string tokenCreado = tokenHandler.WriteToken(tokenConfig);

            return tokenCreado;
        }

        public async Task<AutorizacionResponse> DevolverToken(AutorizacionRequest autorizacion)
        {
            var usuario_econtrado = context.Usuarios.FirstOrDefault(x =>
            x.NombreUsuario == autorizacion.NombreUsuario &&
            x.Clave == autorizacion.Clave
            );

            if (usuario_econtrado == null)
            {
                return await Task.FromResult<AutorizacionResponse>(null);
            }

            string tokenCreado = GenerarToken(usuario_econtrado.IdUsuario.ToString());

            return new AutorizacionResponse() { Token = tokenCreado, Resultado = true, Msg = "Ok" };
        }
    }
}
