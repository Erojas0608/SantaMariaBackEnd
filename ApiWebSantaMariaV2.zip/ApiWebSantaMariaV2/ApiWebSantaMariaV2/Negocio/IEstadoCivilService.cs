﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public interface IEstadoCivilService
    {
        Task<EstadoCivilResponse> Listar();
    }
}
