﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class UbigeoService:IUbigeoService
    {
        private readonly BD_CITAContext context;

        public UbigeoService(BD_CITAContext context)
        {
            this.context = context;
        }

        public async Task<UbigeoResponse> Listar()
        {
            var lista = context.Ubigeos.ToList();
            return new UbigeoResponse() { message = lista, status = "Ok" };
        }
    }
}
