﻿using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public interface IUbigeoService
    {
        Task<UbigeoResponse> Listar();
    }
}
