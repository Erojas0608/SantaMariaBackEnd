﻿using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public interface IPacienteService
    {
        Task<PacienteResponse> Listar();
        Task<JsonResponse> RegistrarPaciente(PacienteRequest request);
    }
}
