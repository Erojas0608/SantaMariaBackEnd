﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class GrupoSanguineoService : IGrupoSanguineoService
    {
        private readonly BD_CITAContext context;

        public GrupoSanguineoService(BD_CITAContext context)
        {
            this.context = context;
        }

        public async Task<GrupoSanguineoResponse> Listar()
        {
            var lista = context.GrupoSanguineos.ToList();
            return new GrupoSanguineoResponse() { message = lista, status = "Ok" };
        }
    }
}
