﻿using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public interface IGradoInstruccionService
    {
        Task<GradoInstruccionResponse> Listar();
    }
}
