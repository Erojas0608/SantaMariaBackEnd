﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class EstadoCivilService : IEstadoCivilService
    {
        private readonly BD_CITAContext context;

        public EstadoCivilService(BD_CITAContext context)
        {
            this.context = context;
        }

        //public async Task<List<EstadoCivil>> Listar()
        //{
        //    var lista = context.EstadoCivils.ToList();
        //    return await Task.FromResult<List<EstadoCivil>>(lista);
        //}
        public async Task<EstadoCivilResponse> Listar()
        {
            var lista = context.EstadoCivils.ToList();
            return new EstadoCivilResponse() { message = lista, status = "Ok" };
        }
    }
}
