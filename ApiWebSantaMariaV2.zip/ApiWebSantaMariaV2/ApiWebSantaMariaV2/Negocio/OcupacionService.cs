﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class OcupacionService : IOcupacionService
    {
        private readonly BD_CITAContext context;

        public OcupacionService(BD_CITAContext context)
        {
            this.context = context;
        }

        public async Task<OcupacionResponse> Listar()
        {
            var lista = context.Ocupacions.ToList();
            return new OcupacionResponse() { message = lista, status = "Ok" };
        }
    }
}
