﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class TipoDocIdentService:ITipoDocIdentService
    {
        private readonly BD_CITAContext context;

        public TipoDocIdentService(BD_CITAContext context)
        {
            this.context = context;
        }

        public async Task<TipoDocIdentResponse> Listar()
        {
            var lista = context.TipoDocIdents.ToList();
            return new TipoDocIdentResponse() { message = lista, status = "Ok" };
        }
    }
}
