﻿using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public interface ISexoService
    {
        Task<SexoResponse> Listar();
    }
}
