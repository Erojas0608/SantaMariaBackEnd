﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class FactorRhService : IFactorRhService
    {
        private readonly BD_CITAContext context;

        public FactorRhService(BD_CITAContext context)
        {
            this.context = context;
        }

        public async Task<FactorRhResponse> Listar()
        {
            var lista = context.FactorRhs.ToList();
            return new FactorRhResponse() { message = lista, status = "Ok" };
        }
    }
}
