﻿using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public interface IFactorRhService
    {
        Task<FactorRhResponse> Listar();
    }
}
