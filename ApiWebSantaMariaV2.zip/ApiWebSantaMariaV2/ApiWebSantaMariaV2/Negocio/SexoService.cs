﻿using ApiWebSantaMariaV2.Models;
using ApiWebSantaMariaV2.Models.Custom;

namespace ApiWebSantaMariaV2.Negocio
{
    public class SexoService : ISexoService
    {
        private readonly BD_CITAContext context;

        public SexoService(BD_CITAContext context)
        {
            this.context = context;
        }

        public async Task<SexoResponse> Listar()
        {
            var lista = context.Sexos.ToList();
            return new SexoResponse() {message=lista, status="Ok" };
        }
    }
}
